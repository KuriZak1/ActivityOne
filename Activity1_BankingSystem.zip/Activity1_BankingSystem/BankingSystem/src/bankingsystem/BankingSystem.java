/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankingsystem;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import org.w3c.dom.Node;


public class BankingSystem {

    static  LinkedList<Integer> usersDeposit = new LinkedList<>();
    static int temp;
    static int loop = 1;
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        do{
           menu();
            System.out.println("Do you want to have another transaction?\n[1] YES. \n[2] NO.");
            int choice = scan.nextInt();
            
            if(choice == 1){
                System.out.println("Ok, Another transaction!");
            }else{
                System.out.println("Ok, Have a nice day!");
                loop++;
            }
        }while(loop == 1);
        
    }
    
    public static void menu(){
        Scanner scan = new Scanner(System.in);
        
            System.out.println("Menu: \n [1] Deposit.\n [2] Withdraw.\n [3]Check Balance.");
            int choice = scan.nextInt();
            
            if(choice == 1){
                deposit();
            }else if (choice == 2){
                withdraw();
            }else if(choice == 3){
                sort();
            }else{
                System.out.println("You can only choose from 1 to 4");
            }
    }
    public static void deposit(){
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Please enter deposit amount: ");
        
        int amount = scan.nextInt();
        usersDeposit.add (amount);
    }
    public static void withdraw(){
        Scanner scan = new Scanner(System.in);

        System.out.println("choose what index you want to withdraw starts in 0.\n");
        sort();
        int amount = scan.nextInt();
        usersDeposit.remove (amount);
    }
    public static void sort(){
        Collections.sort(usersDeposit);
        System.out.println(usersDeposit);
    }
    
}


